# Productivity Hacks for Explorer Tab
# 1. Column filters for Tag, Status, Version
# 2. Search bar with fuzzy assistant lookup
# 3. Multi-select + batch edit mode
# 4. Tag editor with live preview
# 5. Launch button preview modal
# 6. Inline changelog sidebar
# 7. Assistant notes per row (markdown support)
# 8. Color-coded registry row scoring
# 9. Expandable assistant profile drawer
#10. Real-time assistant health status ticker